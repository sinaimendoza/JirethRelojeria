<?php

$conexion = mysqli_connect("localhost", "root", "", "login_register_db");
/*
if($conexion){
    echo 'CONECTADO EXITOSAMENTE A LA BASE DE DATOS';
}else{
    echo 'NO SE HA PODIDO CONECTAR A LA BASE DE DATOS';
}
*/
?>
